[DKFlagFix]
moduleMatches = 0xC9D46C07

; flag fix - independent checkpoint flags + longer time limit
; See NLDECOMP discoveries/DKB_FLAGS.md
;
; ---- Independent flags ----
; Stock collect probe (0x02277CBC):
;   if (manager+1624 > flag.param2) skip collect
; NOP removes the "higher disables lower" gate.
0x02277D00 = nop

; ---- Time limit: 1000 seconds ----
; Timer units are tenths of a second (frames*10/60).
; Stock init (0x02256608):
;   mode A: limit 1000 (100s), pinch 699/899
;   mode B: limit 6000 (600s), pinch 5399/5899  (normal play)
; End when current >= manager+1468 (0x0225B16C).
; Bypass float clamps against shared 6000.0 (0x100687C4)
; so time can run past 600s without freezing.

; mode A thresholds -> 1000s
0x02256614 = addi r4, r0, 10000
0x02256618 = addi r0, r0, 9399
0x02256620 = addi r6, r0, 9899

; mode B thresholds -> 1000s
0x02256638 = addi r8, r0, 10000
0x0225663C = addi r9, r0, 9399
0x02256644 = addi r0, r0, 9899

; never clamp float time to shared 6000.0f
0x02257A00 = b 0x02257A08
0x02257A54 = b 0x02257A60
