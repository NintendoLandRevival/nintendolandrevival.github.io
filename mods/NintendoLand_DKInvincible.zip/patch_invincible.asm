[DKInvincible]
moduleMatches = 0xC9D46C07

; Crash Course invincibility (wall + upside-down)
; See NLDECOMP discoveries/DKB_DEATH.md
;
; Do NOT blr 0x022885CC (breaks roll SFX — shared FX path).
; Do NOT force impact r31=0 / skip DA8 (skips collider +984/+986 marks
; that two-wheel / flat rail+platform contact needs).
; Do NOT blr 0x02287B4C (tails into 0x02287A08 orientation/physics).

; ---- Wall / lean impact ----
; Hurt still runs (roll/hit FX), but never raise death flag +732
0x02288830 = addi r0, r0, 0
; Die register helper: DA8 contact marks still run; never arm +696
0x02287C5C = addi r3, r0, 0
0x02287C60 = blr

; ---- Upside-down / head hits floor ----
; Kill orchestrator only (calls flag setters + wheel kill loop)
0x0228599C = blr
; Sets +972 then heavier kill side effects
0x0227FF04 = blr
; Enter upside mode: allow follow-up helpers, do not set +1517
0x02284874 = addi r0, r0, 0
; Wheel +733 setter: do not set flag, but still fall into 0x02287A08
0x02287B4C = addi r0, r0, 0
; Upside fail-code store (+1504)
0x02284C90 = addi r3, r0, 0
0x02284C94 = blr
