[MroYoshiOne]
moduleMatches = 0xC9D46C07

; Stock 1P spawns two Yoshis (types 6 then 7).
; Keep the first; skip the second.
0x023A908C = b 0x023A9124
