[MroYoshiZero]
moduleMatches = 0xC9D46C07

; Optional alias — Solo now includes zero Yoshis.
; Safe no-op duplicate of the spawn skips only (Solo has the crash guards).
; Prefer Misc/Solo alone for Mario-only Chase.

0x023A8FA4 = addi r5, r0, 0
0x023A8FF0 = b 0x023A9124
0x023A9050 = b 0x023A9124
0x023B6230 = addi r3, r0, 0
0x023B6234 = blr
