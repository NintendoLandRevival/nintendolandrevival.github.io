[MroInvincible]
moduleMatches = 0xC9D46C07

; Mario Chase invincible v9 — Toad cannot tag Mario.
;
; v7/v8: blocking Finish left Mario in caught lock (can't move).
; Real tag apply is here (not only CMTG):
;   0x023A16BC lbz +838 (star)
;   0x023A16C8 bne -> star-bounce @ 16E0
;   else bl 0x02904420  (tag / immobilize)
;
; Force the star-bounce path always so Toads never call tag apply.
0x023A16C8 = b 0x023A16E0

; CMTG apply belt-and-suspenders (keep STAR check reachable):
; stock: beq 0x023A0DBC (CMTG -> catch)
0x023A0CE8 = beq 0x023A141C
0x023A0DBC = b 0x023A141C

; Backup: if anything still latches +813, don't request Finish_Mro.
0x02395B60 = b 0x02395BC4
