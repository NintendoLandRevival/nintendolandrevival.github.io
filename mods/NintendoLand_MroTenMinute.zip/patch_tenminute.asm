[MroTenMinute]
moduleMatches = 0xC9D46C07

; Mario Chase — Ten Minute mod
;
; Round length helper 0x02390968 returns seconds stored at stage+232
; (later *60 for frames):
;   default / large: 150s (2.5 min)
;   small (modes 1/5/9/13): 120s (2 min)
;   special short flag: 11s (leave alone)
;
; Force both normal lengths to 600s = 10 minutes.

0x023909A0 = addi r31, r0, 600
0x023909D4 = addi r31, r0, 600
